import streamlit as st
from planner import make_plan, make_quiz

st.set_page_config(page_title="StudyPilot AI", page_icon="📚", layout="wide")

st.markdown("""
<style>
.stApp {background: linear-gradient(135deg, #081225 0%, #101d38 55%, #142d42 100%); color: #f4f7fb;}
.block-container {max-width: 1100px; padding-top: 2rem;}
.hero {padding: 1.5rem; border: 1px solid #314767; border-radius: 18px; background: rgba(15,30,54,.85);}
.small {color: #a9bfd8;}
</style>
""", unsafe_allow_html=True)

if "completed" not in st.session_state:
    st.session_state.completed = set()

st.markdown('<div class="hero">', unsafe_allow_html=True)
st.title("📚 StudyPilot AI")
st.write("Your personal study planning companion")
st.markdown('<p class="small">Plan your sessions • Practice topics • Track your progress</p>', unsafe_allow_html=True)
st.markdown('</div>', unsafe_allow_html=True)

tab_plan, tab_quiz, tab_about = st.tabs(["🗓️ Study Planner", "🧠 Practice Quiz", "ℹ️ About"])

with tab_plan:
    st.subheader("Build a realistic study plan")
    with st.form("planner_form"):
        subjects_text = st.text_input("Subjects (comma-separated)", "Python, C Programming, English")
        hours = st.slider("Study sessions per day", 1, 8, 3)
        days = st.slider("Plan length (days)", 1, 14, 7)
        submitted = st.form_submit_button("Generate my plan", type="primary")
    if submitted:
        subjects = [x.strip() for x in subjects_text.split(",") if x.strip()]
        if not subjects:
            st.warning("Add at least one subject.")
        else:
            st.session_state.plan = make_plan(subjects, hours, days)
            st.session_state.completed = set()
    if "plan" in st.session_state:
        plan = st.session_state.plan
        st.write(f"**{len(plan)} sessions planned**")
        for item in plan:
            with st.container(border=True):
                cols = st.columns([1, 4, 2])
                cols[0].markdown(f"**Day {item['day']}**")
                cols[1].write(f"**{item['subject']}** — {item['task']}")
                done = cols[2].checkbox("Completed", key=f"done_{item['id']}")
                if done:
                    st.session_state.completed.add(item["id"])
                else:
                    st.session_state.completed.discard(item["id"])
        total = len(plan)
        done_count = len(st.session_state.completed)
        st.progress(done_count / total if total else 0)
        st.metric("Sessions completed", f"{done_count}/{total}")

with tab_quiz:
    st.subheader("Create a practice quiz")
    topic = st.text_input("Topic", "Python variables")
    level = st.selectbox("Difficulty", ["Beginner", "Intermediate"])
    if st.button("Generate quiz"):
        st.session_state.quiz = make_quiz(topic, level)
    if "quiz" in st.session_state:
        st.caption("Starter quiz template. Review questions before relying on them for exams.")
        for i, question in enumerate(st.session_state.quiz, 1):
            st.markdown(f"**Q{i}. {question['question']}**")
            answer = st.radio("Choose an answer", question["options"], key=f"quiz_{i}")
            if st.button(f"Show answer {i}", key=f"show_{i}"):
                st.info(f"Answer: {question['answer']}")

with tab_about:
    st.subheader("About this prototype")
    st.write("StudyPilot AI is a student productivity prototype built with Python and Streamlit.")
    st.write("Current features: study-plan generation, task checkboxes, progress tracking, and a topic-based starter quiz.")
    st.warning("This version uses local template questions; it does not call an AI model or Amazon service yet.")
    st.write("Next development step: implement and test an MCP server, then verify the selected hackathon track's integration requirements.")
