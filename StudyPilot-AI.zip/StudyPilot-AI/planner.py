def make_plan(subjects, sessions_per_day, days):
    tasks = [
        "Learn one concept",
        "Practice examples",
        "Revise notes",
        "Solve practice questions",
    ]
    plan = []
    for i in range(sessions_per_day * days):
        plan.append({
            "id": i,
            "day": i // sessions_per_day + 1,
            "subject": subjects[i % len(subjects)],
            "task": tasks[i % len(tasks)],
        })
    return plan


def make_quiz(topic, level="Beginner"):
    topic = topic.strip() or "general study skills"
    return [
        {
            "question": f"Which is the best first step when learning {topic}?",
            "options": [
                "Understand the basic concept",
                "Memorize everything without understanding",
                "Skip all examples",
                "Avoid practice",
            ],
            "answer": "Understand the basic concept",
        },
        {
            "question": f"How can you check your understanding of {topic}?",
            "options": [
                "Never review the topic",
                "Explain it in your own words and solve practice questions",
                "Only read the title",
                "Avoid asking questions",
            ],
            "answer": "Explain it in your own words and solve practice questions",
        },
        {
            "question": f"What is a useful revision habit for {topic}?",
            "options": [
                "Review after a gap and practice retrieval",
                "Study only once",
                "Ignore mistakes",
                "Avoid taking breaks",
            ],
            "answer": "Review after a gap and practice retrieval",
        },
    ]
