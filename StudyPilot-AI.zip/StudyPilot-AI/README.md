# StudyPilot AI

A beginner-friendly student productivity prototype built with Python and Streamlit.

## Features
- Create a study plan from a list of subjects
- Choose sessions per day and plan length
- Mark sessions complete and track progress
- Generate a starter practice quiz for a topic

## Run locally
1. Install Python 3.10 or later.
2. Open a terminal in this folder.
3. Install dependencies:
   `python -m pip install -r requirements.txt`
4. Start the app:
   `python -m streamlit run app.py`

## Current limitations
- Quiz questions are templates, not AI-generated content.
- Data is stored in the current Streamlit session, not a database.
- No Amazon service or MCP integration is included yet.

## Hackathon checklist
Before submitting, verify the official rules and selected track requirements. Implement and test the required Amazon technology integration, add a public repository with an open-source license, record a real demo video, and complete every required Devpost field. Do not claim integrations or features that are not implemented.
